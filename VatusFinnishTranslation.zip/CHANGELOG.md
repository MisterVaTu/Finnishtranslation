## Release 1.0.0
-Nearly completely translated mod.
-This does not include the terminal.

